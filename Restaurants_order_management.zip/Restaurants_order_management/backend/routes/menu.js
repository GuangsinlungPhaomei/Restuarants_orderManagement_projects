const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const MenuItem = require('../models/MenuItem');

// Multer storage config
const imagesDir = path.join(__dirname, '..', 'public', 'images');
if (!fs.existsSync(imagesDir)) {
  fs.mkdirSync(imagesDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, imagesDir);
  },
  filename: function (req, file, cb) {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-]/g, '_');
    cb(null, `${unique}-${safeName}`);
  }
});

const upload = multer({ storage });

// Get all menu items
router.get('/items', async (req, res) => {
  try {
    const items = await MenuItem.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get menu items by category
router.get('/items/:category', async (req, res) => {
  try {
    const items = await MenuItem.find({ category: req.params.category });
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Add menu item (Admin) - supports image upload (field name: image)
router.post('/items', upload.single('image'), async (req, res) => {
  try {
    const body = req.body || {};
    const menuItemData = {
      name: body.name,
      description: body.description,
      price: body.price ? parseFloat(body.price) : 0,
      category: body.category,
      preparationTime: body.preparationTime ? parseInt(body.preparationTime) : undefined,
      available: body.available === 'false' ? false : true
    };

    if (req.file) {
      // store path relative to server root so frontend can request /uploads/filename
      menuItemData.image = `/uploads/${req.file.filename}`;
    }

    const menuItem = new MenuItem(menuItemData);
    const savedItem = await menuItem.save();
    res.status(201).json(savedItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update menu item - optional image upload
router.patch('/items/:id', upload.single('image'), async (req, res) => {
  try {
    const body = req.body || {};
    const updateData = {};
    if (body.name) updateData.name = body.name;
    if (body.description) updateData.description = body.description;
    if (body.price) updateData.price = parseFloat(body.price);
    if (body.category) updateData.category = body.category;
    if (body.preparationTime) updateData.preparationTime = parseInt(body.preparationTime);
    if (body.available !== undefined) updateData.available = body.available === 'true';

    if (req.file) {
      updateData.image = `/uploads/${req.file.filename}`;
    }

    const item = await MenuItem.findByIdAndUpdate(req.params.id, updateData, { new: true });
    res.json(item);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Delete menu item
router.delete('/items/:id', async (req, res) => {
  try {
    await MenuItem.findByIdAndDelete(req.params.id);
    res.json({ message: 'Item deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
