const mongoose = require('mongoose');
const MenuItem = require('./models/MenuItem');
const Table = require('./models/Table');

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/restaurant_order_management', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const initializeData = async () => {
  try {
    // Check environment variable to control seeding behavior
    const forceReset = process.env.FORCE_SEED === 'true';
    const existingItems = await MenuItem.countDocuments();
    const existingTables = await Table.countDocuments();
    
    // Clear data only if FORCE_SEED is true, otherwise skip if data exists
    if (forceReset) {
      console.log('🔄 Force reset enabled - clearing existing data...');
      await MenuItem.deleteMany({});
      await Table.deleteMany({});
    } else if (existingItems > 0 || existingTables > 0) {
      console.log('✅ Data already exists. Skipping initialization. (Use FORCE_SEED=true to reset)');
      return;
    }

    // Add sample menu items
    const menuItems = [
      {
        name: 'Singju ',
        description: 'Manipur Special dish',
        price: 150,
        category: 'Appetizers',
        preparationTime: 7,
        available: true,
        image: '/uploads/1764091861944-473634504-singju1.jpeg'
      },
      {
        name: 'Paneer Masala',
        description: 'Cottage cheese in aromatic spiced gravy',
        price: 320,
        category: 'Main Course',
        preparationTime: 18,
        available: true,
        image: '/uploads/1764091939263-742104772-butter-chicken-ac2ff98.jpg'
      },
      {
        name: 'Rice Beer ',
        description: 'Naga Traditional Drinks ',
        price: 70,
        category: 'Beverages',
        preparationTime: 3,
        available: true,
        image: '/uploads/1764092007098-766611577-ricebeer.jpeg'
      },
      {
        name: 'Butter Chicken ',
        description: 'Creamy tomato-based curry with succulent chicken pieces',
        price: 380,
        category: 'Main Course',
        preparationTime: 20,
        available: true,
        image: '/uploads/1764092087264-723342151-panneer_masala.jpeg'
      },
      {
        name: 'Garlic Bread ',
        description: 'Crispy Italian bread with garlic butter and herbs',
        price: 150,
        category: 'Appetizers',
        preparationTime: 5,
        available: true,
        image: '/uploads/1764092158011-383129850-Garlicbread.jpeg'
      },
      {
        name: 'Spring Rolls',
        description: 'Crispy rolls filled with vegetables',
        price: 200,
        category: 'Appetizers',
        preparationTime: 9,
        available: true,
        image: '/uploads/1764092269890-282716701-springroll.jpeg'
      },
      {
        name: 'Grill Fish',
        description: 'Fresh fish grilled with lemon and herbs',
        price: 250,
        category: 'Main Course',
        preparationTime: 20,
        available: true,
        image: '/uploads/1764092347692-853770130-grillFish.jpeg'
      },
      {
        name: 'Chicken Biryani',
        description: 'Fragrant basmati rice with tender chicken and spices',
        price: 350,
        category: 'Main Course',
        preparationTime: 20,
        available: true,
        image: '/uploads/1764092442716-851835881-chicken_briyani.jpeg'
      },
      {
        name: 'Fresh Juice',
        description: 'Freshly squeezed orange or mango juice',
        price: 120,
        category: 'Beverages',
        preparationTime: 5,
        available: true,
        image: '/uploads/1764092527073-546424931-freshjuice.jpeg'
      },
      {
        name: 'Lassi',
        description: 'Traditional yogurt-based drink',
        price: 100,
        category: 'Beverages',
        preparationTime: 3,
        available: true,
        image: '/uploads/1764092580250-880398952-lassi.jpeg'
      },
      {
        name: 'Chocolate Cake',
        description: 'Rich chocolate cake with ice cream',
        price: 200,
        category: 'Desserts',
        preparationTime: 10,
        available: true,
        image: '/uploads/1764092675033-48702765-chococake.jpeg'
      },
      {
        name: 'Iced Tea',
        description: 'Refreshing cold tea with lemon',
        price: 70,
        category: 'Beverages',
        preparationTime: 5,
        available: true,
        image: '/uploads/1764092735852-562811075-icetea.jpeg'
      },
      {
        name: 'Cheesecake',
        description: 'Creamy New York style cheesecake',
        price: 250,
        category: 'Desserts',
        preparationTime: 7,
        available: true,
        image: '/uploads/1764092842014-933685356-cheescake.jpeg'
      },
      {
        name: 'Bora',
        description: 'A fried vegetable, Manipur snack ',
        price: 100,
        category: 'Appetizers',
        preparationTime: 10,
        available: true,
        image: '/uploads/1764093020267-935178586-Bora.jpeg'
      },
      {
        name: 'Gulab Jamun',
        description: 'Soft dough balls in sweet syrup',
        price: 150,
        category: 'Desserts',
        preparationTime: 3,
        available: true,
        image: '/uploads/1764093069933-699503982-gulapjamun.jpeg'
      },
      {
        name: 'Fruits Custard',
        description: ' sweet, vanilla-flavored custard base with fresh, chopped seasonal fruits.',
        price: 150,
        category: 'Desserts',
        preparationTime: 10,
        available: true,
        image: '/uploads/1764093268543-491118208-fruitscustard.jpeg'
      }
    ];

    // Add sample tables
    const tables = [
      { tableNumber: 1, capacity: 2, status: 'Available' },
      { tableNumber: 2, capacity: 2, status: 'Available' },
      { tableNumber: 3, capacity: 4, status: 'Available' },
      { tableNumber: 4, capacity: 4, status: 'Available' },
      { tableNumber: 5, capacity: 6, status: 'Available' },
      { tableNumber: 6, capacity: 6, status: 'Available' }
    ];

    await MenuItem.insertMany(menuItems);
    await Table.insertMany(tables);

    console.log('✅ Sample data initialized successfully!');
    console.log(`📝 Added ${menuItems.length} menu items`);
    console.log(`🪑 Added ${tables.length} tables`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error initializing data:', error);
    process.exit(1);
  }
};

initializeData();
