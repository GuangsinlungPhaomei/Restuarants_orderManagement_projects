# 🏗️ Architecture & Technical Documentation

Complete technical architecture of the Restaurant Order Management System.

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (HTML/CSS/JS)                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────┐         ┌──────────────────┐              │
│  │  Admin Dashboard │         │ Customer Menu    │              │
│  │  - Orders List   │         │ - Menu Browse    │              │
│  │  - Kitchen Board │         │ - Cart           │              │
│  │  - Menu Mgmt     │         │ - Order Track    │              │
│  └──────────────────┘         │ - Feedback       │              │
│                               └──────────────────┘              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
                              ↑↓
                    Socket.io (Real-time)
                              ↑↓
┌────────────────────────────────────────────────────────────────┐
│                    BACKEND (Node.js + Express)                 │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   Server (server.js)                    │   │
│  │  - Express app setup                                    │   │
│  │  - Socket.io configuration                              │   │
│  │  - CORS enabled                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ↓                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   Routes Layer                          │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │   │
│  │  │  menu.js     │  │  orders.js   │  │  tables.js   │   │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              ↓                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                 Mongoose Models                         │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐   │   │
│  │  │  MenuItem    │  │  Order       │  │  Table       │   │   │
│  │  │              │  │              │  │              │   │   │
│  │  │ - name       │  │ - orderId    │  │ - tableNum   │   │   │
│  │  │ - price      │  │ - tableNum   │  │ - capacity   │   │   │
│  │  │ - category   │  │ - items      │  │ - status     │   │   │
│  │  │ - prep_time  │  │ - status     │  │ - qrCode     │   │   │
│  │  └──────────────┘  │ - payment    │  └──────────────┘   │   │
│  │                    │ - feedback   │                     │   │
│  │                    └──────────────┘                     │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                │
└────────────────────────────────────────────────────────────────┘
                              ↓
                    MongoDB Driver
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                   DATABASE (MongoDB)                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐     │
│  │ menuitems      │  │ orders         │  │ tables         │     │
│  │ collection     │  │ collection     │  │ collection     │     │
│  │                │  │                │  │                │     │
│  │ [13 items]     │  │ [Multiple      │  │ [6 tables]     │     │
│  │                │  │  orders]       │  │                │     │
│  └────────────────┘  └────────────────┘  └────────────────┘     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---
–––
## Data Flow Diagram

### Customer Order Placement Flow

```
Customer              Frontend             Backend            Database
   │                    │                   │                   │
   │ Opens menu page    │                   │                   │
   ├───────────────────►│                   │                   │
   │                    │ GET /api/menu/items
   │                    ├──────────────────►│                   │
   │                    │                   │ Query menuitems   │
   │                    │                   ├──────────────────►│
   │                    │                   │◄──────────────────┤
   │                    │◄──────────────────┤                   │
   │◄───────────────────┤                   │                   │
   │                    │                   │                   │
   │ Adds items & places│                   │                   │
   │      order         │                   │                   │
   ├───────────────────►│ POST /api/orders/create
   │                    ├──────────────────►│                   │
   │                    │                   │ Create order doc  │
   │                    │                   ├──────────────────►│
   │                    │                   │◄──────────────────┤
   │                    │◄──────────────────┤                   │
   │◄───────────────────┤ + Socket.io emit 'newOrder'           │
   │                    │                   │                   │
   │ Sees "Order       │                    │                   │
   │ Placed" & tracks  │ Socket: joinCustomerWait(orderId)      │
   │    status         │◄─ Listen for 'orderStatusUpdate'      │
   │                   │                                        │
```

### Kitchen Status Update Flow

```
Kitchen Staff         Admin UI            Backend           Database
   │                   │                  │                  │
   │ Kitchen Dashboard │                  │                  │
   │ shows "Pending"   │                  │                  │
   │ orders            │                  │                  │
   │                   │                  │                  │
   │ Clicks "Mark Done"│                  │                  │
   ├──────────────────►│ PATCH /orders/:id/status
   │                   ├─────────────────►│                  │
   │                   │                  │ Update status    │
   │                   │                  │ to "Preparing"   │
   │                   │                  ├─────────────────►│
   │                   │                  │◄─────────────────┤
   │◄──────────────────┤◄─────────────────┤                  │
   │ Order moves to    │ Socket.io emit 'orderStatusUpdate'   │
   │ "Preparing" lane  │ Broadcast to all connected clients  │
   │                   │                  │                  │
   │ Customer sees     │                  │                  │
   │ update real-time  │◄─ Receives 'orderStatusUpdate'       │
   │ in their browser  │                  │                  │
```

---

## Real-time Communication (Socket.io)

### Connection Setup

```javascript
// Backend (server.js)
const io = socketIO(server, {
  cors: {
    origin: 'http://localhost:5000/frontend',
    methods: ['GET', 'POST', 'PATCH']
  }
});

// Frontend Connection
const socket = io('http://localhost:5000');
```

### Event Flow

```
ADMIN JOINS:
  socket.emit('joinAdmin')
     ↓
  Backend puts socket in 'admin' room
     ↓
  Admin receives all 'newOrder' events

KITCHEN JOINS:
  socket.emit('joinKitchen')
     ↓
  Backend puts socket in 'kitchen' room
     ↓
  Kitchen receives all 'newOrder' events

CUSTOMER JOINS:
  socket.emit('joinCustomerWait', orderId)
     ↓
  Backend puts socket in `order-${orderId}` room
     ↓
  Customer only receives updates for their order

NEW ORDER CREATED:
  POST /api/orders/create
     ↓
  io.emit('newOrder', order)  // Broadcast to all
     ↓
  Admin sees order
  Kitchen sees order
  Specific customer sees it if waiting

STATUS UPDATE:
  PATCH /api/orders/:id/status
     ↓
  io.emit('orderStatusUpdate', order)  // Broadcast
     ↓
  Admin dashboard updates
  Kitchen board updates
  Customer's status page updates
```

---

## API Endpoint Structure

```
REST API (Express Routes)
│
├── /api/health
│   └── GET → Server status check
│
├── /api/menu
│   ├── GET /items → Get all menu items
│   ├── GET /items/:category → Filter by category
│   ├── POST /items → Add new item (Admin)
│   ├── PATCH /items/:id → Update item (Admin)
│   └── DELETE /items/:id → Delete item (Admin)
│
├── /api/orders
│   ├── POST /create → Place new order
│   ├── GET / → Get all orders
│   ├── GET /:id → Get specific order
│   ├── GET /table/:tableNumber → Orders for a table
│   ├── PATCH /:id/status → Update order status
│   ├── PATCH /:id/payment → Mark payment
│   └── PATCH /:id/feedback → Add customer feedback
│
└── /api/tables
    ├── GET / → Get all tables
    ├── GET /:tableNumber/qr → Generate QR code
    ├── POST / → Create new table
    └── PATCH /:id → Update table status
```

---

## Database Schema Details

### MenuItem Collection
```javascript
{
  "_id": ObjectId,
  "name": String,              // "Chicken Biryani"
  "description": String,       // "Fragrant rice with chicken"
  "price": Number,             // 350
  "category": String,          // "Main Course"
  "image": String,             // URL or base64
  "available": Boolean,        // true/false
  "preparationTime": Number,   // 25 minutes
  "createdAt": Date,
  "updatedAt": Date
}

// Indexes
db.menuitems.createIndex({ category: 1 })
db.menuitems.createIndex({ available: 1 })
```

### Order Collection
```javascript
{
  "_id": ObjectId,
  "orderId": String,           // "ORD-1700000000000"
  "tableNumber": Number,       // 5
  "items": [                   // Array of ordered items
    {
      "menuItemId": ObjectId,
      "name": String,          // "Chicken Biryani"
      "quantity": Number,      // 2
      "price": Number,         // 350
      "notes": String          // "Less spicy"
    }
  ],
  "status": String,            // "Pending" | "Preparing" | "Ready" | "Served" | "Completed"
  "totalAmount": Number,       // 700
  "paymentStatus": String,     // "Unpaid" | "Paid"
  "customerFeedback": {        // Optional
    "rating": Number,          // 1-5
    "comments": String
  },
  "createdAt": Date,
  "updatedAt": Date
}

// Indexes
db.orders.createIndex({ tableNumber: 1 })
db.orders.createIndex({ status: 1 })
db.orders.createIndex({ paymentStatus: 1 })
```

### Table Collection
```javascript
{
  "_id": ObjectId,
  "tableNumber": Number,       // 1-10
  "capacity": Number,          // 2, 4, 6
  "status": String,            // "Available" | "Occupied" | "Reserved"
  "qrCode": String,            // QR code data URL
  "createdAt": Date,
  "updatedAt": Date
}

// Indexes
db.tables.createIndex({ tableNumber: 1 }, { unique: true })
```

---

## Technology Stack

### Frontend
- **HTML5** - Structure and semantic markup
- **CSS3** - Responsive design with Flexbox/Grid
- **JavaScript (ES6+)** - Client-side logic
- **Socket.io Client** - Real-time updates

**Key Libraries:**
- Socket.io for WebSocket communication
- No framework dependencies (Vanilla JS for simplicity)

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **Socket.io** - Real-time communication
- **Mongoose** - MongoDB ORM
- **CORS** - Cross-origin support
- **QRCode** - QR generation

### Database
- **MongoDB** - NoSQL database
- Document-oriented storage
- Flexible schema
- Horizontal scalability

### Hosting (Production)
- **Backend:** Heroku, AWS EC2, DigitalOcean
- **Frontend:** Netlify, Vercel, GitHub Pages
- **Database:** MongoDB Atlas (Cloud)

---

## Request/Response Examples

### Create Order Request
```json
POST /api/orders/create
Content-Type: application/json

{
  "tableNumber": 5,
  "items": [
    {
      "menuItemId": "507f1f77bcf86cd799439011",
      "name": "Chicken Biryani",
      "quantity": 2,
      "price": 350
    },
    {
      "menuItemId": "507f1f77bcf86cd799439012",
      "name": "Iced Tea",
      "quantity": 2,
      "price": 80
    }
  ]
}
```

### Create Order Response
```json
HTTP/1.1 201 Created
Content-Type: application/json

{
  "_id": "507f1f77bcf86cd799439013",
  "orderId": "ORD-1700123456789",
  "tableNumber": 5,
  "items": [
    {
      "menuItemId": "507f1f77bcf86cd799439011",
      "name": "Chicken Biryani",
      "quantity": 2,
      "price": 350
    },
    {
      "menuItemId": "507f1f77bcf86cd799439012",
      "name": "Iced Tea",
      "quantity": 2,
      "price": 80
    }
  ],
  "status": "Pending",
  "totalAmount": 860,
  "paymentStatus": "Unpaid",
  "customerFeedback": null,
  "createdAt": "2023-11-16T10:30:45.123Z",
  "updatedAt": "2023-11-16T10:30:45.123Z"
}
```

### Update Status Request
```json
PATCH /api/orders/507f1f77bcf86cd799439013/status
Content-Type: application/json

{
  "status": "Preparing"
}
```

### Get Menu Items Response
```json
HTTP/1.1 200 OK
Content-Type: application/json

[
  {
    "_id": "507f1f77bcf86cd799439011",
    "name": "Chicken Biryani",
    "description": "Fragrant rice with tender chicken",
    "price": 350,
    "category": "Main Course",
    "preparationTime": 25,
    "available": true,
    "createdAt": "2023-11-16T09:00:00.000Z",
    "updatedAt": "2023-11-16T09:00:00.000Z"
  }
]
```

---

## Performance Considerations

### Database Optimization
```javascript
// Indexes for fast queries
db.menuitems.createIndex({ category: 1, available: 1 })
db.orders.createIndex({ tableNumber: 1, status: 1 })
db.orders.createIndex({ createdAt: -1 })  // Latest orders first

// Query optimization
// Good: db.orders.find({ status: "Pending", tableNumber: 5 })
// Better: db.orders.find({ status: "Pending", tableNumber: 5 }).limit(10)
```

### Socket.io Optimization
```javascript
// Use rooms for targeted updates
io.to('kitchen').emit('newOrder', order)      // Only kitchen
io.to(`order-${orderId}`).emit('update', ...)  // Only customer
io.to('admin').emit('stats', ...)              // Only admin

// Don't broadcast to all clients
// io.emit('event')  // This reaches everyone (inefficient)
```

### Frontend Optimization
```javascript
// Cache menu items in localStorage
localStorage.setItem('menuItems', JSON.stringify(items))

// Debounce real-time updates
const debouncedUpdate = debounce(updateUI, 300)

// Lazy load images
<img src="..." loading="lazy" />
```

---

## Security Best Practices (Production)

### Authentication
```javascript
// Add JWT authentication
const jwt = require('jsonwebtoken');

router.post('/login', (req, res) => {
  const token = jwt.sign({ userId: user._id }, 'secret');
  res.json({ token });
});

// Middleware to verify token
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  jwt.verify(token, 'secret', (err, decoded) => {
    if (err) return res.status(401).json({ error: 'Unauthorized' });
    req.user = decoded;
    next();
  });
};

router.get('/admin/orders', verifyToken, getOrders);
```

### Input Validation
```javascript
const { body, validationResult } = require('express-validator');

router.post('/orders/create', 
  body('tableNumber').isInt({ min: 1 }),
  body('items').isArray(),
  body('items.*.quantity').isInt({ min: 1 }),
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    // Process order
  }
);
```

### Rate Limiting
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,  // 15 minutes
  max: 100  // limit each IP to 100 requests per windowMs
});

app.use('/api/', limiter);
```

---

## Scalability Strategy

### Horizontal Scaling
```
Load Balancer (Nginx)
    ├─ Backend Instance 1 (Port 5000)
    ├─ Backend Instance 2 (Port 5001)
    └─ Backend Instance 3 (Port 5002)
         ↓
    MongoDB Replica Set
```

### Caching Layer
```javascript
const redis = require('redis');
const client = redis.createClient();

// Cache menu items
app.get('/api/menu/items', (req, res) => {
  client.get('menuItems', (err, cached) => {
    if (cached) return res.json(JSON.parse(cached));
    
    MenuItem.find().then(items => {
      client.setex('menuItems', 3600, JSON.stringify(items));
      res.json(items);
    });
  });
});
```

### Message Queue (for heavy operations)
```javascript
const amqp = require('amqplib');

// Publish order to queue
await channel.sendToQueue('orders', Buffer.from(JSON.stringify(order)));

// Consumer processes orders
channel.consume('orders', (msg) => {
  const order = JSON.parse(msg.content);
  processOrder(order);
  channel.ack(msg);
});
```

---

## Monitoring & Logging

### Application Logging
```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

logger.info('Order created', { orderId, tableNumber });
logger.error('Database error', { error });
```

### Metrics & Analytics
```javascript
// Track response times
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(`${req.method} ${req.path} - ${duration}ms`);
  });
  next();
});
```

---

## Deployment Checklist

- [ ] Environment variables configured
- [ ] Database backups set up
- [ ] SSL/HTTPS enabled
- [ ] CORS properly configured
- [ ] Rate limiting enabled
- [ ] Input validation in place
- [ ] Error handling implemented
- [ ] Logging configured
- [ ] Monitoring set up
- [ ] Database indexes created
- [ ] Load testing done
- [ ] Security audit completed

---

This architecture supports real-time order management with scalability, security, and performance in mind.
