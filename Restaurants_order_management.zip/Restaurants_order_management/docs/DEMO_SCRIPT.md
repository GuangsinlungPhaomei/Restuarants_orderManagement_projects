# 🎬 Demo Script for Viva/Presentation

Complete step-by-step demo guide to showcase your Restaurant Order Management System.

---

## 📋 Pre-Demo Checklist (30 minutes before)

- [ ] Start MongoDB: `net start MongoDB`
- [ ] Start Backend: `npm start` in backend folder
- [ ] Wait for: "✅ MongoDB Connected" message
- [ ] Wait for: "🚀 Server running on http://localhost:5000"
- [ ] Test health: `curl http://localhost:5000/api/health`
- [ ] Initialize data: `npm run seed` (if needed)
- [ ] Open 3 browser windows
- [ ] Test all URLs load without errors

---

## ⏱️ Demo Timeline: 20 Minutes Total

| Time | Activity | Duration |
|------|----------|----------|
| 0:00 - 0:02 | Introduction & Architecture | 2 min |
| 0:02 - 0:07 | Customer Flow Demo | 5 min |
| 0:07 - 0:12 | Admin Dashboard Demo | 5 min |
| 0:12 - 0:17 | Real-Time Updates | 5 min |
| 0:17 - 0:20 | Q&A | 3 min |

---

## 📌 Part 1: Introduction & Architecture (2 minutes)

### Script:
"Welcome to the Restaurant Order Management System. This project demonstrates a complete end-to-end solution with three key features:

1. **QR-Based Dynamic Menu** - Customers scan a QR code at their table and instantly access the menu
2. **Kitchen Dashboard** - Real-time Kanban board for efficient order management
3. **Real-Time Updates** - Socket.io enables instant notifications across the system

The architecture consists of:
- Frontend: HTML/CSS/JavaScript (no frameworks - pure vanilla JS)
- Backend: Node.js with Express
- Database: MongoDB
- Real-time: Socket.io WebSockets"

### Show:
- Open Terminal showing backend running
- Point to logs showing "✅ MongoDB Connected"

---

## 🛒 Part 2: Customer Flow Demo (5 minutes)

### Browser Window 1: Customer Menu

**URL:** `http://localhost:5000/frontend/customer.html?table=1`

### Script:
"Let me show you the customer experience. A customer sits at Table 1 and scans a QR code which brings them here.

The customer can:
- Browse menu by category (Appetizers, Main, Desserts, Beverages)
- See real-time prices and preparation times
- Add items to their cart"

### Actions:
1. **Show Menu Categories**
   - Click through each category tab
   - Point out "Appetizers", "Main Course", "Desserts", "Beverages"
   - Show that 13 items are available

2. **Add Items to Cart**
   - Click on "Garlic Bread" → Click "Add"
   - Click on "Chicken Biryani" (increase qty to 2) → Click "Add"
   - Point out cart updates on right sidebar
   - Show "Total: ₹___" calculating in real-time

3. **Place Order**
   - Click "Place Order" button
   - Show "Order Placed" confirmation
   - Read Order ID out loud: "ORD-1700..."

4. **Show Order Status Page**
   - Click "View Status"
   - Explain timeline: "⏳ Pending → 👨‍🍳 Preparing → ✨ Ready → 🍽️ Served"
   - Point out real-time status tracking

---

## 👨‍💼 Part 3: Admin Dashboard Demo (5 minutes)

### Browser Window 2: Admin Dashboard

**URL:** `http://localhost:5000/frontend/admin.html`

### Script Part A: Dashboard Tab
"Now let's look at what the admin and kitchen staff see. The admin dashboard has three main sections."

### Actions:
1. **Show Dashboard Overview**
   - Point to summary cards at top
   - Explain: "Total Orders, Pending, Preparing, Ready counts"
   - Say "These update in real-time as customers place orders"

2. **Show Orders Table**
   - Scroll down to see orders table
   - Point out columns: Order ID, Table, Items, Amount, Status, Payment
   - Explain each column's purpose

3. **View Order Details**
   - Click "View" on the order we just placed
   - Modal opens showing:
     - Order ID
     - Table Number
     - Items ordered (with quantities)
     - Total amount
     - Status and payment status

### Script Part B: Kitchen Tab
"Now let me show you the Kitchen Dashboard. This is where the real magic happens."

### Actions:
1. **Switch to Kitchen Tab**
   - Click "Kitchen" button in navbar
   - Explain: "This is a Kanban board showing order workflow"

2. **Show Three Lanes**
   ```
   Pending Lane      | Preparing Lane   | Ready Lane
   (Red background)  | (Orange)         | (Green)
   [Order Card]      | [Empty]          | [Empty]
   Table 1           |                  |
   2x Garlic Bread   |                  |
   2x Biryani        |                  |
   ```
   - Point out order in Pending lane
   - Explain: "Each card shows table number and what to prepare"

3. **Update Order Status**
   - In "Pending" lane, click "Mark Done"
   - Order should move to "Preparing" lane
   - Say: "Notice the order automatically moved to the Preparing lane"

4. **Move to Ready**
   - In "Preparing" lane, click "Mark Done"
   - Order moves to "Ready" lane
   - Say: "Now it's ready for the waiter to serve"

### Script Part C: Menu Tab
"The admin can also manage menu items."

### Actions:
1. **Click Menu Tab**
2. **Show Menu Grid**
   - Display all 13 menu items
   - Point out: Name, description, price, prep time
3. **Show Add Item Form** (Optional if time permits)
   - Click "+ Add Menu Item"
   - Show form with fields
   - Say: "Staff can add new dishes in seconds"

---

## ⚡ Part 4: Real-Time Updates Showcase (5 minutes)

### The Magic Moment - Show Real-Time Communication

### Script:
"Now I'll demonstrate the real-time updates. Watch closely - I'll place an order from a customer, and you'll see it instantly appear in the admin dashboard without refreshing."

### Setup:
- **Browser 1 (Customer):** `http://localhost:5000/frontend/customer.html?table=2`
- **Browser 2 (Admin):** `http://localhost:5000/frontend/admin.html` (Dashboard tab)
- **Browser 3 (Kitchen):** `http://localhost:5000/frontend/admin.html` (Kitchen tab)

### Actions:

1. **Arrange Windows Side-by-Side**
   - Resize windows so all 3 are visible
   - Show customer page on left
   - Show admin dashboard in middle
   - Show kitchen board on right

2. **Place New Order (Customer)**
   - In Browser 1, add items to cart
   - Click "Place Order"
   - Note the time

3. **Watch Real-Time Update**
   - In Browser 2 (Admin Dashboard):
     - New order appears in table instantly! ✓
     - Summary counters update (Pending count +1) ✓
     - No refresh needed ✓
   - In Browser 3 (Kitchen Board):
     - New order card appears in Pending lane! ✓
     - Kitchen staff sees it immediately ✓

4. **Update Status and Watch Customer See It**
   - In Browser 3 (Kitchen), click "Mark Done"
   - In Browser 1 (Customer), watch status update:
     - Timeline dot becomes active ✓
     - Message changes to "👨‍🍳 Your food is being prepared!" ✓
     - No page refresh needed ✓

5. **Mark as Ready**
   - In Browser 3, click "Mark Done" again
   - In Browser 1, status changes again:
     - "✨ Your food is ready! Please come to the counter." ✓

### Explanation:
"Notice how everything updates instantly across all browsers without any manual refresh. This is Socket.io - a WebSocket technology that enables real-time bidirectional communication. When someone updates something on the server, all connected clients receive the update instantly."

---

## 💡 Part 5: Key Features Highlight (1 minute)

### During Q&A or as Summary:

**Feature 1: QR-Based System**
- "Customers just scan QR → instant menu access"
- "No passwords, no registration - just scan and order"
- "Each table has unique QR with table number encoded"

**Feature 2: Real-Time Updates**
- "Uses Socket.io for WebSocket communication"
- "Orders appear instantly (< 100ms)"
- "No polling, no lag, truly real-time"

**Feature 3: Kitchen Efficiency**
- "Kanban board helps organize workflow"
- "Clear visual status progression"
- "Reduces confusion and improves speed"

**Feature 4: Mobile Friendly**
- "Responsive design works on any device"
- "Customers can use their phones"
- "Admin can manage from any screen"

---

## 🎓 Expected Visitor Questions & Answers

### Q1: "Why MongoDB instead of SQL?"
A: "MongoDB's flexibility is perfect for restaurant data - items, orders, feedback can vary. It's also easier to scale horizontally. For this use case, we don't need ACID transactions."

### Q2: "How many simultaneous orders can it handle?"
A: "With this setup, easily 100+ concurrent users. For thousands, we'd add:
- Load balancing (Nginx)
- Redis caching
- Database replication
- Microservices architecture"

### Q3: "How do you handle lost connections?"
A: "Socket.io automatically reconnects when connection drops. Plus, customers can refresh and continue from where they left off since the order is saved in the database."

### Q4: "Can this scale to a chain of restaurants?"
A: "Absolutely! We'd add:
- Multi-tenant database (restaurant_id field)
- Different admin portals per restaurant
- Centralized analytics dashboard
- Restaurant hierarchy for chain management"

### Q5: "What about security?"
A: "In production, we'd add:
- JWT authentication for staff
- Password encryption
- Rate limiting on API
- Input validation on all fields
- HTTPS/SSL encryption"

### Q6: "How do you generate revenue with this?"
A: "Multiple models:
- SaaS model (₹500-2000/month per restaurant)
- Payment processing fee (2-3%)
- Premium features (analytics, loyalty program)
- Delivery integration add-ons"

### Q7: "Can customers make reservations?"
A: "We can add that! Would involve:
- Add reservation collection to database
- Add availability calendar on customer page
- Send confirmations via SMS/email
- Sync with POS system"

---

## 🎬 Live Demo Troubleshooting

### Problem: Backend crashes during demo
```
Fix: Ctrl+C, then npm start
Say: "Just restarting the service, this is normal"
```

### Problem: Real-time update doesn't happen
```
Check: 
  - Is Socket.io connected? (browser console)
  - Are there server errors? (terminal)
Fix: Refresh page, reconnect will happen automatically
```

### Problem: Menu items not loading
```
Fix: npm run seed
Say: "Just initializing the database"
```

### Problem: Port 5000 already in use
```
Before demo, change to 5001 in .env
Update frontend URLs accordingly
```

---

## 📸 Screenshot Moments

Capture these moments for your report:

1. **Customer menu page** with items visible
2. **Order placed** confirmation screen
3. **Admin dashboard** showing order in table
4. **Kitchen Kanban board** with orders
5. **Real-time update** - customer seeing status change
6. **Feedback system** - rating prompt
7. **Multiple browsers** showing real-time sync

---

## 🎤 Opening Statement (30 seconds)

"Good morning/afternoon! I've created a complete Restaurant Order Management System that demonstrates real-world application architecture. It features QR-based customer menus, a real-time kitchen dashboard, and instant order status updates. The system uses Node.js backend, MongoDB database, and Socket.io for real-time communication. Let me walk you through how it works..."

---

## 🎤 Closing Statement (30 seconds)

"What you've seen today is a production-ready system that solves real problems for restaurants. The real-time updates reduce wait times, the kitchen dashboard improves efficiency, and the customer feedback system helps restaurants improve their service. This architecture can scale from a single restaurant to a chain of hundreds. Thank you!"

---

## ✅ Success Criteria

Your demo is successful if:

- ✅ All three features work (QR menu, Kitchen dashboard, Real-time updates)
- ✅ No errors or crashes during demo
- ✅ Real-time updates happen visibly
- ✅ Audience understands the workflow
- ✅ You can answer at least 5 questions confidently
- ✅ Code is clean and understandable
- ✅ Performance is smooth and responsive

---

## 📝 Demo Notes Template

Print this and make notes:

```
Demo Date: ___________
Audience: ____________

What worked well:
- 
- 

What could improve:
- 
- 

Questions asked:
1. _____________ → Answer: _____________
2. _____________ → Answer: _____________
3. _____________ → Answer: _____________

Feedback received:
- 
- 

Follow-up actions:
- 
- 
```

---

## 🏆 Pro Tips for Excellent Demo

1. **Practice beforehand** - Run through the demo 2-3 times
2. **Have backup data** - Pre-place some orders before starting
3. **Show browser console** - Helps explain real-time events
4. **Keep talking** - Silence makes demos feel awkward
5. **Show enthusiasm** - Your energy matters!
6. **Have internet ready** - Keep WiFi active
7. **Backup plan** - Have screenshots if demo fails
8. **Time management** - Watch your clock
9. **Ask if they want code review** - Shows confidence
10. **Be humble about limitations** - Shows maturity

---

**Good luck with your demo! You've got this! 🚀**
