const API_URL = 'http://localhost:5000/api';
const socket = io('http://localhost:5000');

let tableNumber = null;
let currentOrderId = null;
let cart = {};
let menuItems = [];
let currentFilter = 'Appetizers';
let currentRating = 0;

// Get table number from URL
function getTableNumber() {
  const params = new URLSearchParams(window.location.search);
  return params.get('table');
}

// Initialize
window.addEventListener('DOMContentLoaded', () => {
  tableNumber = getTableNumber();
  if (!tableNumber) {
    tableNumber = prompt('Enter table number:');
  }
  document.getElementById('table-number').textContent = tableNumber;
  loadMenu();
});

// Load menu items
async function loadMenu() {
  try {
    const response = await fetch(`${API_URL}/menu/items`);
    menuItems = await response.json();
    displayMenu();
  } catch (error) {
    console.error('Error loading menu:', error);
  }
}

// Display menu items
function displayMenu() {
  const grid = document.getElementById('menu-grid');
  grid.innerHTML = '';

  const filtered = menuItems.filter(item => item.category === currentFilter && item.available);

  if (filtered.length === 0) {
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center;">No items available</p>';
    return;
  }

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'menu-item-card';
    const imgHtml = item.image ? `<img src="http://localhost:5000${item.image}" alt="${item.name}" class="menu-item-thumb"/>` : '';
    card.innerHTML = `
      ${imgHtml}
      <h3>${item.name}</h3>
      <p class="item-desc">${item.description}</p>
      <p class="item-price">₹${item.price}</p>
      <p class="item-time">⏱️ ${item.preparationTime} min</p>
      <div class="item-controls">
        <button onclick="decreaseQty('${item._id}')" class="btn-qty">−</button>
        <span id="qty-${item._id}" class="qty-display">0</span>
        <button onclick="increaseQty('${item._id}', '${item.name}', ${item.price})" class="btn-qty">+</button>
      </div>
      <button onclick="addToCart('${item._id}', '${item.name}', ${item.price})" class="btn btn-small btn-primary">Add</button>
    `;
    grid.appendChild(card);
  });
}

// Filter by category
function filterCategory(category) {
  currentFilter = category;
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  displayMenu();
}

// Add to cart
function addToCart(itemId, name, price) {
  const qty = parseInt(document.getElementById(`qty-${itemId}`).textContent) || 1;
  
  if (cart[itemId]) {
    cart[itemId].quantity += qty;
  } else {
    cart[itemId] = { name, price, quantity: qty };
  }

  updateCart();
  document.getElementById(`qty-${itemId}`).textContent = '0';
}

// Increase quantity
function increaseQty(itemId, name, price) {
  const current = parseInt(document.getElementById(`qty-${itemId}`).textContent) || 0;
  document.getElementById(`qty-${itemId}`).textContent = current + 1;
}

// Decrease quantity
function decreaseQty(itemId) {
  const current = parseInt(document.getElementById(`qty-${itemId}`).textContent) || 0;
  if (current > 0) {
    document.getElementById(`qty-${itemId}`).textContent = current - 1;
  }
}

// Update cart display
function updateCart() {
  const cartContainer = document.getElementById('cart-items');
  const cartBtn = document.getElementById('place-order-btn');
  
  if (Object.keys(cart).length === 0) {
    cartContainer.innerHTML = '<p class="empty-cart">No items selected</p>';
    cartBtn.style.display = 'none';
    return;
  }

  cartBtn.style.display = 'block';
  let total = 0;
  let html = '';

  Object.values(cart).forEach((item, index) => {
    const itemTotal = item.price * item.quantity;
    total += itemTotal;
    html += `
      <div class="cart-item">
        <div>
          <p>${item.quantity}x ${item.name}</p>
          <p class="item-total">₹${itemTotal}</p>
        </div>
        <button onclick="removeFromCart(${index})" class="btn-remove">❌</button>
      </div>
    `;
  });

  cartContainer.innerHTML = html;
  document.getElementById('total-price').textContent = total;
}

// Remove from cart
function removeFromCart(index) {
  const keys = Object.keys(cart);
  delete cart[keys[index]];
  updateCart();
}

// Place order
async function placeOrder() {
  const items = Object.entries(cart).map(([id, item]) => ({
    menuItemId: id,
    name: item.name,
    quantity: item.quantity,
    price: item.price
  }));

  try {
    const response = await fetch(`${API_URL}/orders/create`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tableNumber: parseInt(tableNumber),
        items: items
      })
    });

    const order = await response.json();
    currentOrderId = order._id;
    
    // Show confirmation
    document.getElementById('order-id').textContent = order.orderId;
    document.getElementById('order-modal').style.display = 'block';

    cart = {};
  } catch (error) {
    console.error('Error placing order:', error);
    alert('Failed to place order');
  }
}

// Close order modal and show status
function closeOrderModal() {
  document.getElementById('order-modal').style.display = 'none';
  showOrderStatus();
}

// Show order status page
function showOrderStatus() {
  document.querySelector('.customer-container').style.display = 'none';
  document.getElementById('status-page').style.display = 'block';

  socket.emit('joinCustomerWait', currentOrderId);
  updateOrderStatus();
  
  // Listen for order updates
  socket.on('orderStatusUpdate', (order) => {
    if (order._id === currentOrderId) {
      updateOrderStatus();
    }
  });

  // Refresh status every 3 seconds
  setInterval(updateOrderStatus, 3000);
}

// Update order status display
async function updateOrderStatus() {
  try {
    const response = await fetch(`${API_URL}/orders/${currentOrderId}`);
    const order = await response.json();

    document.getElementById('status-order-id').textContent = order.orderId;
    document.getElementById('status-table').textContent = tableNumber;

    // Update timeline
    const statuses = ['Pending', 'Preparing', 'Ready', 'Served', 'Completed'];
    statuses.forEach(status => {
      const dot = document.getElementById(`dot-${status.toLowerCase()}`);
      if (dot) {
        if (statuses.indexOf(status) <= statuses.indexOf(order.status)) {
          dot.classList.add('active');
        }
      }
    });

    // Update message
    const messages = {
      'Pending': '⏳ Your order is queued. We are getting started!',
      'Preparing': '👨‍🍳 Your food is being prepared!',
      'Ready': '✨ Your food is ready! Please come to the counter.',
      'Served': '🍽️ Enjoy your meal!',
      'Completed': '✅ Thank you for dining with us!'
    };

    document.getElementById('status-message').textContent = messages[order.status] || '';

    // Show feedback after served
    if (order.status === 'Served' && !order.customerFeedback) {
      document.getElementById('feedback-section').style.display = 'block';
    }

  } catch (error) {
    console.error('Error updating status:', error);
  }
}

// Rating system
function setRating(rating) {
  currentRating = rating;
  document.querySelectorAll('.star').forEach((star, index) => {
    if (index < rating) {
      star.style.color = '#FFD700';
    } else {
      star.style.color = '#ccc';
    }
  });
}

// Submit feedback
async function submitFeedback() {
  const comments = document.getElementById('feedback-text').value;

  try {
    await fetch(`${API_URL}/orders/${currentOrderId}/feedback`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        rating: currentRating,
        comments: comments
      })
    });

    alert('✅ Thank you for your feedback!');
    skipFeedback();
  } catch (error) {
    console.error('Error submitting feedback:', error);
  }
}

// Skip feedback
function skipFeedback() {
  document.getElementById('feedback-section').style.display = 'none';
}

// Go back to menu
function goBackToMenu() {
  document.querySelector('.customer-container').style.display = 'block';
  document.getElementById('status-page').style.display = 'none';
  cart = {};
  updateCart();
  loadMenu();
}
