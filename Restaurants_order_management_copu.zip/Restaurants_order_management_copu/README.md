# 🍽️ Restaurant Order Management System

A complete, production-ready restaurant order management system with real-time updates, QR-based menu, kitchen dashboard, and admin portal.

---

## ⭐ Key Features

### ✅ QR-Based Dynamic Menu
- Customers scan QR code at their table
- Opens a dynamic menu with real-time availability
- Items organized by categories (Appetizers, Main Course, Desserts, Beverages)
- Real-time price and preparation time display

### ✅ Kitchen Dashboard
- Live order tracking with Kanban-style board
- Orders organized by status (Pending → Preparing → Ready → Served)
- Quick visual updates when order status changes
- Kitchen staff can mark orders as done with one click

### ✅ Real-Time Order Updates
- Socket.io integration for instant notifications
- Customers see live order status updates
- Staff receives instant new order notifications
- Admin gets real-time dashboard updates

---

## 🏗️ Architecture

```
Frontend (HTML/CSS/JavaScript)
    ↓
Backend (Node.js + Express)
    ↓
Database (MongoDB)
    ↑
Real-time Communication (Socket.io)
```

### Frontend
- **admin.html/admin.js** - Admin dashboard & kitchen panel
- **customer.html/customer.js** - Customer menu & order tracking
- **styles.css** - Unified styling

### Backend
- **server.js** - Express + Socket.io server
- **routes/menu.js** - Menu management endpoints
- **routes/orders.js** - Order management endpoints
- **routes/tables.js** - Table & QR management
- **models/** - MongoDB schemas

---

## 📋 Complete Workflow

### 👤 Customer Journey
```
1. Customer sits at Table
   ↓
2. Scans QR Code → Opens customer.html with table number
   ↓
3. Browses Menu (organized by categories)
   ↓
4. Adds Items to Cart
   ↓
5. Places Order
   ↓
6. Sees Order Confirmation with Order ID
   ↓
7. Watches Real-Time Status Updates:
   ⏳ Pending → 👨‍🍳 Preparing → ✨ Ready → 🍽️ Served
   ↓
8. Receives Rating Prompt
   ↓
9. Gives Feedback ⭐ (optional)
   ↓
10. Staff brings food & collects bill
```

### 👨‍💼 Staff/Admin Journey
```
1. Staff logs into admin.html
   ↓
2. Dashboard shows:
   - Total orders summary
   - Pending orders count
   - Preparing orders count
   - Ready orders count
   ↓
3. Can switch to Kitchen Tab to see:
   - Pending Orders Lane
   - Preparing Orders Lane
   - Ready for Pickup Lane
   ↓
4. Mark order status as done → moves to next lane automatically
   ↓
5. Admin Dashboard tab shows:
   - All orders in table format
   - Payment status
   - Customer details
   - Can mark payment as "Paid"
   - Can view order details
   ↓
6. Menu Tab allows:
   - Add new menu items
   - Delete items
   - View all items
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 14+ installed
- MongoDB running locally or connection string ready
- npm or yarn

### 1️⃣ Install Backend Dependencies

```bash
cd backend
npm install
```

### 2️⃣ Configure Database

Edit `backend/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/restaurant_order_management
NODE_ENV=development
```

**Option A: Local MongoDB**
```bash
# Start MongoDB service (Windows)
mongod

# Or using Windows PowerShell
net start MongoDB
```

**Option B: MongoDB Atlas (Cloud)**
- Create free account at https://www.mongodb.com/cloud/atlas
- Replace `MONGODB_URI` with your connection string:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/restaurant_order_management?retryWrites=true&w=majority
```

### 3️⃣ Start Backend Server

```bash
# From backend folder
npm start
# or for development with auto-reload:
npm run dev
```

Expected output:
```
✅ MongoDB Connected
🚀 Server running on http://localhost:5000
```

### 4️⃣ Access Frontend

**Admin Dashboard:**
```
http://localhost:5000/frontend/admin.html
```

**Customer Menu (for Table 1):**
```
http://localhost:5000/frontend/customer.html?table=1
```

---

## 🔌 API Endpoints

### Menu Management
```
GET    /api/menu/items                 # Get all menu items
GET    /api/menu/items/:category       # Get items by category
POST   /api/menu/items                 # Add new item
PATCH  /api/menu/items/:id             # Update item
DELETE /api/menu/items/:id             # Delete item
```

### Order Management
```
POST   /api/orders/create              # Create new order
GET    /api/orders                     # Get all orders
GET    /api/orders/:id                 # Get order by ID
GET    /api/orders/table/:tableNumber  # Get orders by table
PATCH  /api/orders/:id/status          # Update order status
PATCH  /api/orders/:id/payment         # Update payment status
PATCH  /api/orders/:id/feedback        # Add customer feedback
```

### Table Management
```
GET    /api/tables                     # Get all tables
GET    /api/tables/:tableNumber/qr     # Get QR code for table
POST   /api/tables                     # Create new table
PATCH  /api/tables/:id                 # Update table
```

### Health Check
```
GET    /api/health                     # Server status
```

---

## 🎯 Sample Data Setup

Insert sample menu items in MongoDB:

```javascript
db.menuitems.insertMany([
  {
    "name": "Garlic Bread",
    "description": "Crispy bread with garlic butter",
    "price": 150,
    "category": "Appetizers",
    "preparationTime": 5,
    "available": true
  },
  {
    "name": "Chicken Biryani",
    "description": "Fragrant rice with tender chicken",
    "price": 350,
    "category": "Main Course",
    "preparationTime": 25,
    "available": true
  },
  {
    "name": "Chocolate Cake",
    "description": "Rich chocolate dessert with ice cream",
    "price": 200,
    "category": "Desserts",
    "preparationTime": 10,
    "available": true
  },
  {
    "name": "Iced Tea",
    "description": "Refreshing cold tea",
    "price": 80,
    "category": "Beverages",
    "preparationTime": 2,
    "available": true
  }
])
```

Or access the admin panel at `admin.html` and use the "Menu" tab to add items through the UI.

---

## 📱 Database Schema

### MenuItem
```json
{
  "_id": ObjectId,
  "name": "Dish Name",
  "description": "Description",
  "price": 350,
  "category": "Main Course",
  "image": "url",
  "available": true,
  "preparationTime": 25
}
```

### Order
```json
{
  "_id": ObjectId,
  "orderId": "ORD-1234567890",
  "tableNumber": 5,
  "items": [
    {
      "menuItemId": ObjectId,
      "name": "Chicken Biryani",
      "quantity": 2,
      "price": 350,
      "notes": "Less spicy"
    }
  ],
  "status": "Preparing",
  "totalAmount": 700,
  "paymentStatus": "Unpaid",
  "customerFeedback": {
    "rating": 5,
    "comments": "Excellent food!"
  },
  "createdAt": ISODate,
  "updatedAt": ISODate
}
```

### Table
```json
{
  "_id": ObjectId,
  "tableNumber": 1,
  "capacity": 4,
  "status": "Occupied",
  "qrCode": "base64_qr_image"
}
```

---

## 🔄 Real-Time Events (Socket.io)

### Events Emitted:
```javascript
// New order notification
socket.emit('newOrder', orderObject)

// Order status update
socket.emit('orderStatusUpdate', orderObject)

// Payment update
socket.emit('paymentUpdate', orderObject)
```

### Events Listened:
```javascript
// Kitchen staff join
socket.emit('joinKitchen')

// Customer join specific order
socket.emit('joinCustomerWait', orderId)

// Admin join
socket.emit('joinAdmin')
```

---

## 🎨 UI Features

### Admin Dashboard
- 📊 Real-time summary cards (Total, Pending, Preparing, Ready)
- 📋 Complete orders table with filters
- 👀 View order details in modal
- 💳 Mark payments as done
- 🔄 Update order status

### Kitchen Dashboard
- 👨‍🍳 Kanban board with 3 lanes (Pending, Preparing, Ready)
- 🎯 Drag-and-drop ready orders
- ⚡ One-click status updates
- 📱 Mobile-friendly card design

### Customer Menu
- 🔍 Category-based filtering
- 🛒 Real-time cart management
- 💰 Dynamic pricing display
- ⏱️ Preparation time visibility
- 📊 Order status tracking with timeline
- ⭐ Feedback system

---

## 🐛 Troubleshooting

### MongoDB Connection Error
```
❌ Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution:** Start MongoDB service
```bash
net start MongoDB  # Windows
brew services start mongodb-community  # Mac
```

### Socket.io Connection Error
```
CORS error: Access denied
```
**Solution:** Check `server.js` and update CORS origin:
```javascript
const io = socketIO(server, {
  cors: {
    origin: 'http://localhost:3000',  // Change to your frontend URL
    methods: ['GET', 'POST', 'PATCH']
  }
});
```

### Orders Not Updating in Real-Time
- Check browser console for errors
- Verify Socket.io connection is established
- Check firewall settings for port 5000

---

## 📦 Project Structure

```
Restaurants_order_management/
├── backend/
│   ├── config/
│   │   └── database.js
│   ├── models/
│   │   ├── MenuItem.js
│   │   ├── Order.js
│   │   └── Table.js
│   ├── routes/
│   │   ├── menu.js
│   │   ├── orders.js
│   │   └── tables.js
│   ├── server.js
│   ├── package.json
│   └── .env
│
└── frontend/
    ├── admin.html
    ├── admin.js
    ├── customer.html
    ├── customer.js
    └── styles.css
```

---

## 🚀 Deployment

### Deploy to Heroku

1. Create `Procfile` in backend folder:
```
web: node server.js
```

2. Create `runtime.txt`:
```
node-16.x
```

3. Deploy:
```bash
heroku create your-app-name
git push heroku main
```

### Deploy Frontend
- Use GitHub Pages, Netlify, or any static hosting
- Update API_URL in JavaScript files to your backend URL

---

## 📊 Performance Tips

1. **Database Indexing:**
```javascript
// Add indexes for frequently queried fields
db.orders.createIndex({ tableNumber: 1 })
db.orders.createIndex({ status: 1 })
```

2. **Caching:**
- Cache menu items in browser localStorage
- Reduce database calls for static data

3. **Pagination:**
- Add limit/offset for large order lists
- Implement infinite scroll if needed

---

## 🔐 Security Considerations

⚠️ **For Production:**

1. Add authentication/authorization:
```javascript
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });
  // Verify token
  next();
};
```

2. Validate input data:
```javascript
const { body, validationResult } = require('express-validator');

router.post('/orders/create', 
  body('tableNumber').isInt({ min: 1 }),
  body('items').isArray(),
  // ... validation logic
);
```

3. Use HTTPS/SSL certificates

4. Set up environment variables for sensitive data

5. Implement rate limiting to prevent abuse

---

## 📈 Next Steps / Enhancement Ideas

1. **Authentication System**
   - Staff login with username/password
   - Role-based access control (Admin, Chef, Waiter)

2. **Payment Integration**
   - Integrate with Razorpay, Stripe, or PayPal
   - Generate bills with QR code

3. **Analytics Dashboard**
   - Peak hours analysis
   - Most popular items
   - Revenue reports

4. **Mobile App**
   - React Native or Flutter app
   - Push notifications for order updates

5. **Advanced Features**
   - Table reservations
   - Online ordering
   - Delivery management
   - Loyalty program

---

## 💡 Tips for Viva/Demo

### Show These Features:
1. ✅ Scan QR → Place order immediately
2. ✅ See real-time status updates (use 2 browsers)
3. ✅ Kitchen dashboard with Kanban board
4. ✅ Admin can view all orders and manage
5. ✅ Payment marking and feedback system
6. ✅ Multiple tables operating simultaneously

### During Demo:
- Use sample data (insert 5-10 menu items)
- Have multiple orders in different statuses
- Show Socket.io real-time updates
- Demonstrate status transition workflow
- Show feedback/rating system

---

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review MongoDB connection
3. Check server logs for errors
4. Verify Socket.io connection in browser DevTools

---

## 📄 License

MIT License - Feel free to use and modify

---

**🎉 You now have a complete, production-ready restaurant order management system!**

Start the server and begin taking orders! 🚀
