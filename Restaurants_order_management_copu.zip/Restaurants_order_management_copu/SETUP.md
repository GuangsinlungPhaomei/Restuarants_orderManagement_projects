# 🚀 Step-by-Step Setup Guide

Complete setup instructions to get your Restaurant Order Management System running.

---

## Step 1: Install MongoDB

### Windows
1. Download from: https://www.mongodb.com/try/download/community
2. Run installer and follow prompts
3. MongoDB will be installed as a Windows service

**Verify Installation:**
```powershell
mongod --version
```

**Start MongoDB Service:**
```powershell
net start MongoDB
```

### Mac
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

### Linux (Ubuntu)
```bash
sudo apt-get install -y mongodb
sudo systemctl start mongodb
```

---

## Step 2: Clone/Setup Project

```bash
cd c:\Users\guang\Desktop\WTMP\project\Restaurants_order_management
```

---

## Step 3: Install Backend Dependencies

```bash
cd backend
npm install
```

This installs:
- ✅ Express.js - Web framework
- ✅ Mongoose - MongoDB ORM
- ✅ Socket.io - Real-time communication
- ✅ CORS - Cross-origin requests
- ✅ QRCode - QR generation

---

## Step 4: Configure Environment

Edit `backend/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/restaurant_order_management
NODE_ENV=development
```

---

## Step 5: Initialize Sample Data

```bash
npm run seed
```

This will:
- ✅ Create 13 sample menu items (across 4 categories)
- ✅ Create 6 sample tables
- ✅ Clear old data

**Expected Output:**
```
✅ Sample data initialized successfully!
📝 Added 13 menu items
🪑 Added 6 tables
```

---

## Step 6: Start Backend Server

```bash
npm start
```

**Expected Output:**
```
✅ MongoDB Connected
🚀 Server running on http://localhost:5000
```

---

## Step 7: Access Frontend

Open your browser and navigate to:

### Admin Dashboard
```
http://localhost:5000/frontend/admin.html
```

### Customer Menu (Table 1)
```
http://localhost:5000/frontend/customer.html?table=1
```

### Customer Menu (Other Tables)
```
http://localhost:5000/frontend/customer.html?table=2
http://localhost:5000/frontend/customer.html?table=3
... and so on
```

---

## ✅ Verification Checklist

- [ ] MongoDB service is running
- [ ] Backend server started successfully
- [ ] Can access admin dashboard without errors
- [ ] Can access customer menu page
- [ ] Menu items are loaded (13 items visible)
- [ ] Can add items to cart
- [ ] Can place an order
- [ ] Order appears in admin dashboard real-time

---

## 🎯 Quick Test Workflow

### 1. Open Two Browser Windows

**Window 1 (Admin):** http://localhost:5000/frontend/admin.html
**Window 2 (Customer):** http://localhost:5000/frontend/customer.html?table=1

### 2. Customer Places Order
- Select items from menu
- Click "Place Order"
- Note the Order ID

### 3. Admin Sees Order
- Order appears in Dashboard
- Visible in "Pending" column in Kitchen view
- All counters update in real-time

### 4. Update Order Status
- Click "Update" on the order in Admin dashboard
- Status changes to "Preparing"
- Customer sees update in real-time

### 5. Mark as Ready
- Click "Update" again
- Status changes to "Ready"
- Customer receives notification

---

## 🐛 Common Issues & Solutions

### Issue 1: "MongoDB not found" error
```
Error: connect ECONNREFUSED 127.0.0.1:27017
```
**Solution:**
```powershell
net start MongoDB  # Windows
# or
brew services start mongodb-community  # Mac
```

### Issue 2: Port 5000 already in use
```
Error: listen EADDRINUSE :::5000
```
**Solution:** Change PORT in `.env`:
```env
PORT=5001  # Use different port
```

### Issue 3: CORS errors in browser console
**Solution:** Update `server.js`:
```javascript
const io = socketIO(server, {
  cors: {
    origin: 'http://localhost:3000',  // Your frontend URL
    methods: ['GET', 'POST', 'PATCH']
  }
});
```

### Issue 4: Socket.io not connecting
- Check browser DevTools Console
- Verify backend is running
- Check firewall settings for port 5000

### Issue 5: Menu items not loading
```
Solution:
npm run seed  # Re-initialize data
```

---

## 📦 Folder Structure

```
Restaurants_order_management/
│
├── backend/
│   ├── config/
│   │   └── database.js           # MongoDB connection
│   ├── models/
│   │   ├── MenuItem.js           # Menu schema
│   │   ├── Order.js              # Order schema
│   │   └── Table.js              # Table schema
│   ├── routes/
│   │   ├── menu.js               # Menu endpoints
│   │   ├── orders.js             # Order endpoints
│   │   └── tables.js             # Table endpoints
│   ├── server.js                 # Express + Socket.io server
│   ├── seedData.js               # Sample data initialization
│   ├── package.json              # Dependencies
│   └── .env                      # Configuration
│
└── frontend/
    ├── admin.html                # Admin dashboard UI
    ├── admin.js                  # Admin logic
    ├── customer.html             # Customer menu UI
    ├── customer.js               # Customer logic
    └── styles.css                # All styling
```

---

## 🎨 Frontend URLs Reference

| Page | URL | Purpose |
|------|-----|---------|
| Admin | `http://localhost:5000/frontend/admin.html` | Dashboard, Kitchen, Menu Mgmt |
| Customer - Table 1 | `http://localhost:5000/frontend/customer.html?table=1` | Order placement |
| Customer - Table 2 | `http://localhost:5000/frontend/customer.html?table=2` | Order placement |
| Customer - Table 3 | `http://localhost:5000/frontend/customer.html?table=3` | Order placement |
| Customer - Table 4 | `http://localhost:5000/frontend/customer.html?table=4` | Order placement |
| Customer - Table 5 | `http://localhost:5000/frontend/customer.html?table=5` | Order placement |
| Customer - Table 6 | `http://localhost:5000/frontend/customer.html?table=6` | Order placement |

---

## 🔄 API Testing

### Test health check
```bash
curl http://localhost:5000/api/health
# Response: {"status":"✅ Server is running"}
```

### Get all menu items
```bash
curl http://localhost:5000/api/menu/items
```

### Get all orders
```bash
curl http://localhost:5000/api/orders
```

### Get all tables
```bash
curl http://localhost:5000/api/tables
```

---

## 📊 Admin Dashboard Features

### Dashboard Tab
- Summary cards showing order statistics
- Complete orders table with all details
- Quick view and update buttons

### Kitchen Tab
- Kanban board with 3 lanes
- Pending orders (red)
- Preparing orders (orange)
- Ready for pickup (green)
- One-click status updates

### Menu Tab
- Add new menu items
- View all items
- Delete items
- Filter by category

---

## 👤 Customer Page Features

### Order Placement
- Browse menu by category
- Add/remove items from cart
- Real-time cart total
- Place order

### Order Tracking
- Real-time status updates
- Timeline visualization
- Estimated wait time
- Status messages

### Feedback
- Star rating system
- Comments section
- Optional feedback

---

## 🎓 For Your Viva Presentation

### Key Points to Highlight
1. ✅ **QR-Based System** - Scan QR → Instant menu access
2. ✅ **Real-time Updates** - Socket.io for live notifications
3. ✅ **Kitchen Dashboard** - Kanban board for efficient workflow
4. ✅ **Complete Workflow** - End-to-end order management
5. ✅ **Scalability** - MongoDB for handling multiple orders

### Demo Flow
1. Open admin dashboard
2. Open 3 customer pages (different tables)
3. Place orders from each customer page
4. Show real-time updates in admin
5. Update order status in kitchen
6. Show customer sees updates
7. Mark as ready and show feedback system
8. Explain technical stack and architecture

---

## 💡 Next Steps

1. **Production Deployment**
   - Deploy backend to Heroku/AWS
   - Deploy frontend to Netlify/Vercel
   - Use MongoDB Atlas for cloud database

2. **Additional Features**
   - Staff authentication
   - Payment gateway integration
   - Mobile app development
   - Advanced reporting

3. **Optimization**
   - Add caching layer
   - Implement pagination
   - Database indexing
   - API rate limiting

---

## 📞 Getting Help

If something doesn't work:

1. **Check MongoDB Status**
   ```powershell
   Get-Service MongoDB  # Windows
   ```

2. **Check Backend Logs**
   - Look for error messages in terminal
   - Check browser DevTools Console (F12)

3. **Restart Everything**
   ```bash
   # Terminal 1: Restart MongoDB
   net stop MongoDB
   net start MongoDB
   
   # Terminal 2: Restart backend
   npm start
   ```

4. **Clear Browser Cache**
   - Hard refresh (Ctrl+Shift+R)
   - Clear cookies

---

**You're all set! 🎉 Start taking orders!**
