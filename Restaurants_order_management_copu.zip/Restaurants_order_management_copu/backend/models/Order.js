const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  orderId: {
    type: String,
    unique: true,
    required: true
  },
  tableNumber: {
    type: Number,
    required: true
  },
  items: [
    {
      menuItemId: mongoose.Schema.Types.ObjectId,
      name: String,
      quantity: Number,
      price: Number,
      notes: String
    }
  ],
  status: {
    type: String,
    enum: ['Pending', 'Preparing', 'Ready', 'Served', 'Completed'],
    default: 'Pending'
  },
  totalAmount: Number,
  paymentStatus: {
    type: String,
    enum: ['Unpaid', 'Paid'],
    default: 'Unpaid'
  },
  customerFeedback: {
    rating: Number,
    comments: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, { timestamps: true });

module.exports = mongoose.model('Order', OrderSchema);
