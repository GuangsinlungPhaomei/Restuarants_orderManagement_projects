const mongoose = require('mongoose');

const TableSchema = new mongoose.Schema({
  tableNumber: {
    type: Number,
    unique: true,
    required: true
  },
  capacity: Number,
  status: {
    type: String,
    enum: ['Available', 'Occupied', 'Reserved'],
    default: 'Available'
  },
  qrCode: String
}, { timestamps: true });

module.exports = mongoose.model('Table', TableSchema);
