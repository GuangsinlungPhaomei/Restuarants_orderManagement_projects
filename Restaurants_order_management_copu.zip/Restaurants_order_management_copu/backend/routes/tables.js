const express = require('express');
const router = express.Router();
const Table = require('../models/Table');
const qrcode = require('qrcode');

// Get all tables
router.get('/', async (req, res) => {
  try {
    const tables = await Table.find();
    res.json(tables);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Generate QR code for table
router.get('/:tableNumber/qr', async (req, res) => {
  try {
    const table = await Table.findOne({ tableNumber: req.params.tableNumber });
    if (!table) return res.status(404).json({ message: 'Table not found' });

    const qrData = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/customer?table=${req.params.tableNumber}`;
    const qrCode = await qrcode.toDataURL(qrData);
    
    res.json({ qrCode, table });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create table
router.post('/', async (req, res) => {
  const table = new Table(req.body);
  try {
    const savedTable = await table.save();
    res.status(201).json(savedTable);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Update table status
router.patch('/:id', async (req, res) => {
  try {
    const table = await Table.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(table);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
