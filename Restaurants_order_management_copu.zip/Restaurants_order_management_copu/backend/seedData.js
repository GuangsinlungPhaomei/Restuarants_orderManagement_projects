const mongoose = require('mongoose');
const MenuItem = require('./models/MenuItem');
const Table = require('./models/Table');

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/restaurant_order_management', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const initializeData = async () => {
  try {
    // Clear existing data
    await MenuItem.deleteMany({});
    await Table.deleteMany({});

    // Add sample menu items
    const menuItems = [
      // Appetizers
      {
        name: 'Garlic Bread',
        description: 'Crispy Italian bread with garlic butter and herbs',
        price: 150,
        category: 'Appetizers',
        preparationTime: 5,
        available: true
      },
      {
        name: 'Paneer Tikka',
        description: 'Marinated cottage cheese grilled to perfection',
        price: 280,
        category: 'Appetizers',
        preparationTime: 10,
        available: true
      },
      {
        name: 'Spring Rolls',
        description: 'Crispy rolls filled with vegetables',
        price: 200,
        category: 'Appetizers',
        preparationTime: 8,
        available: true
      },
      // Main Course
      {
        name: 'Chicken Biryani',
        description: 'Fragrant basmati rice with tender chicken and spices',
        price: 350,
        category: 'Main Course',
        preparationTime: 25,
        available: true
      },
      {
        name: 'Butter Chicken',
        description: 'Creamy tomato-based curry with succulent chicken pieces',
        price: 380,
        category: 'Main Course',
        preparationTime: 20,
        available: true
      },
      {
        name: 'Paneer Masala',
        description: 'Cottage cheese in aromatic spiced gravy',
        price: 320,
        category: 'Main Course',
        preparationTime: 18,
        available: true
      },
      {
        name: 'Grilled Fish',
        description: 'Fresh fish grilled with lemon and herbs',
        price: 420,
        category: 'Main Course',
        preparationTime: 22,
        available: true
      },
      // Desserts
      {
        name: 'Chocolate Cake',
        description: 'Rich chocolate cake with ice cream',
        price: 200,
        category: 'Desserts',
        preparationTime: 10,
        available: true
      },
      {
        name: 'Gulab Jamun',
        description: 'Soft dough balls in sweet syrup',
        price: 150,
        category: 'Desserts',
        preparationTime: 8,
        available: true
      },
      {
        name: 'Cheesecake',
        description: 'Creamy New York style cheesecake',
        price: 250,
        category: 'Desserts',
        preparationTime: 5,
        available: true
      },
      // Beverages
      {
        name: 'Iced Tea',
        description: 'Refreshing cold tea with lemon',
        price: 80,
        category: 'Beverages',
        preparationTime: 2,
        available: true
      },
      {
        name: 'Lassi',
        description: 'Traditional yogurt-based drink',
        price: 100,
        category: 'Beverages',
        preparationTime: 3,
        available: true
      },
      {
        name: 'Fresh Juice',
        description: 'Freshly squeezed orange or mango juice',
        price: 120,
        category: 'Beverages',
        preparationTime: 5,
        available: true
      }
    ];

    // Add sample tables
    const tables = [
      { tableNumber: 1, capacity: 2, status: 'Available' },
      { tableNumber: 2, capacity: 2, status: 'Available' },
      { tableNumber: 3, capacity: 4, status: 'Available' },
      { tableNumber: 4, capacity: 4, status: 'Available' },
      { tableNumber: 5, capacity: 6, status: 'Available' },
      { tableNumber: 6, capacity: 6, status: 'Available' }
    ];

    await MenuItem.insertMany(menuItems);
    await Table.insertMany(tables);

    console.log('✅ Sample data initialized successfully!');
    console.log(`📝 Added ${menuItems.length} menu items`);
    console.log(`🪑 Added ${tables.length} tables`);
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error initializing data:', error);
    process.exit(1);
  }
};

initializeData();
