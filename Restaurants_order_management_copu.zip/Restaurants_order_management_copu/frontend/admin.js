const API_URL = 'http://localhost:5000/api';
const socket = io('http://localhost:5000');

let currentOrderId = null;
let allOrders = [];

// Socket.io event listeners
socket.emit('joinAdmin');

socket.on('newOrder', (order) => {
  console.log('📩 New order received:', order);
  fetchOrders();
});

socket.on('orderStatusUpdate', (order) => {
  console.log('🔄 Order status updated:', order);
  fetchOrders();
});

socket.on('paymentUpdate', (order) => {
  console.log('💳 Payment updated:', order);
  fetchOrders();
});

// Switch between views
function switchView(viewName) {
  document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
  document.getElementById(`${viewName}-view`).classList.add('active');
  
  document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
  event.target.classList.add('active');

  if (viewName === 'kitchen') {
    loadKitchenBoard();
  } else if (viewName === 'menu') {
    loadMenuItems();
  }
}

// Fetch all orders
async function fetchOrders() {
  try {
    const response = await fetch(`${API_URL}/orders`);
    allOrders = await response.json();
    updateDashboard();
    updateOrdersTable();
  } catch (error) {
    console.error('Error fetching orders:', error);
  }
}

// Update dashboard summary
function updateDashboard() {
  const total = allOrders.length;
  const pending = allOrders.filter(o => o.status === 'Pending').length;
  const preparing = allOrders.filter(o => o.status === 'Preparing').length;
  const ready = allOrders.filter(o => o.status === 'Ready').length;

  document.getElementById('total-orders').textContent = total;
  document.getElementById('pending-count').textContent = pending;
  document.getElementById('preparing-count').textContent = preparing;
  document.getElementById('ready-count').textContent = ready;
}

// Update orders table
function updateOrdersTable() {
  const tbody = document.getElementById('orders-tbody');
  tbody.innerHTML = '';

  allOrders.forEach(order => {
    const itemsText = order.items.map(item => `${item.quantity}x ${item.name}`).join(', ');
    const row = document.createElement('tr');
    row.innerHTML = `
      <td><strong>${order.orderId}</strong></td>
      <td>Table ${order.tableNumber}</td>
      <td>${itemsText}</td>
      <td>₹${order.totalAmount}</td>
      <td><span class="status-badge ${order.status.toLowerCase()}">${order.status}</span></td>
      <td>${order.paymentStatus}</td>
      <td>
        <button onclick="viewOrderDetails('${order._id}')" class="btn-small">View</button>
        <button onclick="updateOrderStatus('${order._id}')" class="btn-small">Update</button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

// View order details
function viewOrderDetails(orderId) {
  currentOrderId = orderId;
  const order = allOrders.find(o => o._id === orderId);
  if (!order) return;

  const modalBody = document.getElementById('modal-body');
  const itemsHTML = order.items.map(item => `
    <div class="item-detail">
      <span>${item.quantity}x ${item.name}</span>
      <span>₹${item.price * item.quantity}</span>
      ${item.notes ? `<p>Note: ${item.notes}</p>` : ''}
    </div>
  `).join('');

  modalBody.innerHTML = `
    <p><strong>Order ID:</strong> ${order.orderId}</p>
    <p><strong>Table:</strong> ${order.tableNumber}</p>
    <p><strong>Status:</strong> ${order.status}</p>
    <p><strong>Payment:</strong> ${order.paymentStatus}</p>
    <p><strong>Total:</strong> ₹${order.totalAmount}</p>
    <h4>Items:</h4>
    ${itemsHTML}
    ${order.customerFeedback ? `
      <h4>Feedback:</h4>
      <p>Rating: ⭐${order.customerFeedback.rating}/5</p>
      <p>Comment: ${order.customerFeedback.comments}</p>
    ` : ''}
  `;

  document.getElementById('order-modal').style.display = 'block';
}

// Update order status
async function updateOrderStatus(orderId) {
  const order = allOrders.find(o => o._id === orderId);
  const statuses = ['Pending', 'Preparing', 'Ready', 'Served', 'Completed'];
  const currentIndex = statuses.indexOf(order.status);
  const nextStatus = statuses[currentIndex + 1] || statuses[0];

  try {
    await fetch(`${API_URL}/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus })
    });
    fetchOrders();
    alert(`Order status updated to: ${nextStatus}`);
  } catch (error) {
    console.error('Error updating status:', error);
  }
}

// Mark as paid
async function markAsPaid() {
  if (!currentOrderId) return;

  try {
    await fetch(`${API_URL}/orders/${currentOrderId}/payment`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentStatus: 'Paid' })
    });
    fetchOrders();
    closeModal();
    alert('✅ Payment marked as done');
  } catch (error) {
    console.error('Error updating payment:', error);
  }
}

// Load kitchen board
async function loadKitchenBoard() {
  await fetchOrders();
  
  const pending = allOrders.filter(o => o.status === 'Pending');
  const preparing = allOrders.filter(o => o.status === 'Preparing');
  const ready = allOrders.filter(o => o.status === 'Ready');

  populateLane('lane-pending', pending);
  populateLane('lane-preparing', preparing);
  populateLane('lane-ready', ready);
}

// Populate kitchen lane
function populateLane(laneId, orders) {
  const lane = document.getElementById(laneId);
  lane.innerHTML = '';

  orders.forEach(order => {
    const card = document.createElement('div');
    card.className = 'kitchen-card';
    const itemsHTML = order.items.map(item => `
      <div class="kitchen-item">
        <span class="qty">${item.quantity}</span>
        <span>${item.name}</span>
      </div>
    `).join('');

    card.innerHTML = `
      <h3>Table ${order.tableNumber}</h3>
      <p class="order-time">Order #${order.orderId.split('-')[1].slice(-4)}</p>
      ${itemsHTML}
      <button onclick="moveToNextStatus('${order._id}')" class="btn btn-small btn-success">Mark Done</button>
    `;
    lane.appendChild(card);
  });
}

// Move order to next status
async function moveToNextStatus(orderId) {
  const order = allOrders.find(o => o._id === orderId);
  const statuses = ['Pending', 'Preparing', 'Ready', 'Served', 'Completed'];
  const currentIndex = statuses.indexOf(order.status);
  const nextStatus = statuses[Math.min(currentIndex + 1, statuses.length - 1)];

  try {
    await fetch(`${API_URL}/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: nextStatus })
    });
    loadKitchenBoard();
  } catch (error) {
    console.error('Error updating status:', error);
  }
}

// Load menu items
async function loadMenuItems() {
  try {
    const response = await fetch(`${API_URL}/menu/items`);
    const items = await response.json();
    
    const grid = document.getElementById('menu-items-grid');
    grid.innerHTML = '';

    items.forEach(item => {
      const card = document.createElement('div');
      card.className = 'menu-card';
      card.innerHTML = `
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <p><strong>₹${item.price}</strong> | ${item.category}</p>
        <p>⏱️ ${item.preparationTime} min</p>
        <button onclick="deleteMenuItem('${item._id}')" class="btn btn-small btn-danger">Delete</button>
      `;
      grid.appendChild(card);
    });
  } catch (error) {
    console.error('Error loading menu:', error);
  }
}

// Show add menu form
function showAddMenuForm() {
  document.getElementById('menu-modal').style.display = 'block';
}

// Add menu item
async function addMenuItem(event) {
  event.preventDefault();

  const newItem = {
    name: document.getElementById('item-name').value,
    description: document.getElementById('item-desc').value,
    price: parseFloat(document.getElementById('item-price').value),
    category: document.getElementById('item-category').value,
    preparationTime: parseInt(document.getElementById('item-prep-time').value) || 15,
    available: true
  };

  try {
    await fetch(`${API_URL}/menu/items`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newItem)
    });
    alert('✅ Menu item added');
    closeMenuModal();
    loadMenuItems();
  } catch (error) {
    console.error('Error adding item:', error);
  }
}

// Delete menu item
async function deleteMenuItem(itemId) {
  if (!confirm('Are you sure?')) return;

  try {
    await fetch(`${API_URL}/menu/items/${itemId}`, { method: 'DELETE' });
    loadMenuItems();
  } catch (error) {
    console.error('Error deleting item:', error);
  }
}

// Modal functions
function closeModal() {
  document.getElementById('order-modal').style.display = 'none';
}

function closeMenuModal() {
  document.getElementById('menu-modal').style.display = 'none';
  document.getElementById('menu-form').reset();
}

// Initial load
fetchOrders();
setInterval(fetchOrders, 5000); // Refresh every 5 seconds
